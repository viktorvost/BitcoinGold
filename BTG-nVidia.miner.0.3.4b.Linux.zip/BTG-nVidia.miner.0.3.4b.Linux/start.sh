./miner --server eu1-btg.cloudhash.eu --user n1eCSx4qvGS3neiU2Z9AoLTUFpSxSadXMs.Worker --pass x --port 7001
